<?php
/**
 * REST API for event access
 * @version 2.8
 */